<?php

/**
 * @file
 * Template for the Flex Slider row item
 *
 * @author Mathew Winstone (minorOffense) <mwinstone@coldfrontlabs.ca>
 */

print $item;
