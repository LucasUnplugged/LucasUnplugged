About
=====

This adds a new display style to views called "Flex Slider". Similar to how you select "HTML List" or "Unformatted List" as display styles.

This module doesn't require Views UI to be enabled but it is required if you want to configure your Views display using Flex Slider through the web interface. This ensures you can leave Views UI off once everything is setup.

Usage
=====

Go to Views andUse the display mode "FlexSlider"