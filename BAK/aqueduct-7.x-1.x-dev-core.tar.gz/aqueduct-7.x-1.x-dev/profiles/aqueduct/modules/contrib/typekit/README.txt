This simple module makes it easy to include the Typekit library on your site. You will have to have an account at Typekit (http://typekit.com/).


Installation
==================
* Regular module installation process.
* Go to admin/config/user-interface/typekit to put in your "key"
  and determine how you want Typekit to show up.



Author(s)
==================
zzolo (http://drupal.org/user/147331)
jpamental (http://drupal.org/user/174960)