<div class="<?php print $classes; ?>">
  <?php print $item; ?>
</div>
